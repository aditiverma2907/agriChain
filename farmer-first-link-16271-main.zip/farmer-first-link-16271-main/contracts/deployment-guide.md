# Complete Blockchain Deployment Guide for AgriChain

## Overview
This guide will help you deploy the AgriChain smart contract and integrate it with your web application.

## Prerequisites
- MetaMask wallet installed (https://metamask.io/download/)
- Some test ETH for deployment (get from faucets)
- Basic understanding of blockchain and smart contracts

## Step 1: Get Test ETH

### For Sepolia Testnet (Recommended)
1. Go to https://sepoliafaucet.com/
2. Connect your MetaMask wallet
3. Request test ETH (you'll need ~0.1 ETH for deployment)

### Alternative Faucets
- https://faucets.chain.link/
- https://www.alchemy.com/faucets/ethereum-sepolia

## Step 2: Deploy Smart Contract Using Remix

### 2.1 Open Remix IDE
1. Go to https://remix.ethereum.org/
2. Create a new file called `AgriChainSupplyChain.sol`

### 2.2 Copy Contract Code
1. Copy the entire content from `contracts/AgriChainSupplyChain.sol`
2. Paste it into the Remix editor

### 2.3 Compile Contract
1. Click on the "Solidity Compiler" tab (left sidebar)
2. Select compiler version 0.8.0 or higher
3. Click "Compile AgriChainSupplyChain.sol"
4. Ensure there are no errors

### 2.4 Deploy Contract
1. Click on "Deploy & Run Transactions" tab
2. In "Environment" dropdown, select "Injected Provider - MetaMask"
3. MetaMask will popup - connect your account
4. Ensure you're on Sepolia network in MetaMask
5. Click "Deploy" button
6. MetaMask will ask you to confirm the transaction
7. Wait for the transaction to be confirmed (~15 seconds)

### 2.5 Copy Contract Address
After successful deployment:
1. You'll see your deployed contract at the bottom of the page
2. Click the copy icon next to the contract address
3. **SAVE THIS ADDRESS** - you'll need it next!

## Step 3: Update Your Application

### 3.1 Update Contract Address
1. Open `src/lib/blockchain.ts` in your code editor
2. Find the line:
   ```typescript
   export const AGRICHAIN_CONTRACT_ADDRESS = '0x0000000000000000000000000000000000000000';
   ```
3. Replace `'0x0000000000000000000000000000000000000000'` with your deployed contract address
4. Example:
   ```typescript
   export const AGRICHAIN_CONTRACT_ADDRESS = '0x1234567890abcdef1234567890abcdef12345678';
   ```

### 3.2 Verify Network Configuration
In the same file, ensure the network is set correctly:
```typescript
export const BLOCKCHAIN_NETWORK = 'sepolia'; // Change to 'mumbai' if using Polygon
```

## Step 4: Test Your Integration

### 4.1 Connect Wallet
1. Open your AgriChain application
2. Navigate to the Farmer dashboard
3. Click "Connect Wallet" button
4. Approve the connection in MetaMask
5. Ensure MetaMask is on Sepolia network

### 4.2 Register a Product
1. Fill in product details in the Farmer form
2. Click "Register Product & Generate QR Code"
3. MetaMask will popup asking to confirm the transaction
4. Click "Confirm" and wait for the transaction
5. You should see a success message with the blockchain transaction hash

### 4.3 Update Supply Chain
1. As a Retailer or Wholesaler, search for the product ID
2. Add price increase and location
3. Click "Add to Supply Chain"
4. Confirm the MetaMask transaction
5. Verify the blockchain badge appears

### 4.4 View as Consumer
1. Navigate to Consumer page
2. Search for or scan the product QR code
3. You should see:
   - Blockchain verified badge
   - Transaction hash
   - "View on Explorer" link

## Step 5: Verify on Block Explorer

1. Click "View on Explorer" link on any product
2. You should see your transaction on Sepolia Etherscan
3. Verify the transaction details match your product information

## Troubleshooting

### Error: "MetaMask not installed"
- Install MetaMask browser extension
- Refresh your application page

### Error: "Wrong network"
- Open MetaMask
- Click network dropdown at top
- Select "Sepolia Test Network"
- If you don't see it, enable "Show test networks" in MetaMask settings

### Error: "Insufficient funds"
- Get more test ETH from faucets listed above
- You need some ETH for each transaction

### Error: "Transaction failed"
- Check your gas settings in MetaMask
- Ensure you have enough ETH for gas fees
- Try increasing gas limit

### Contract address shows as 0x000...
- You haven't deployed the contract yet
- Follow Step 2 to deploy
- Update the address in Step 3

### Blockchain features not showing
- Ensure you've updated `AGRICHAIN_CONTRACT_ADDRESS`
- Check browser console for errors
- Verify you're connected to the correct network

## Production Deployment

⚠️ **WARNING**: This guide uses testnets. For production:

1. **Security Audit**: Have your smart contract audited by professionals
2. **Use Mainnet**: Deploy to Ethereum mainnet or Polygon mainnet
3. **Real ETH**: You'll need real ETH/MATIC for deployment and transactions
4. **Gas Optimization**: Optimize contract to reduce gas costs
5. **Access Control**: Consider adding role-based access control
6. **Upgradeability**: Consider using proxy patterns for contract upgrades

### Mainnet Deployment Costs (Approximate)
- Ethereum Mainnet: $50-200 (varies with gas prices)
- Polygon Mainnet: $0.01-1 (much cheaper alternative)

## Alternative: Using Hardhat (Advanced)

If you prefer command-line deployment:

```bash
# Install Hardhat
npm install --save-dev hardhat @nomicfoundation/hardhat-toolbox

# Initialize Hardhat
npx hardhat init

# Copy contract to contracts folder
# Create deployment script
# Configure hardhat.config.js with your network

# Deploy
npx hardhat run scripts/deploy.js --network sepolia
```

## Support and Resources

- Remix Documentation: https://remix-ide.readthedocs.io/
- MetaMask Documentation: https://docs.metamask.io/
- Ethers.js Documentation: https://docs.ethers.org/
- Sepolia Etherscan: https://sepolia.etherscan.io/

## Next Steps

After successful deployment:
1. Test all features (register, update, view)
2. Generate QR codes and test scanning
3. Verify all blockchain transactions on explorer
4. Consider adding more features:
   - Product reviews
   - Quality certifications
   - Temperature tracking
   - Multi-signature approvals

---

**Need Help?** Check the troubleshooting section or open an issue in the project repository.
