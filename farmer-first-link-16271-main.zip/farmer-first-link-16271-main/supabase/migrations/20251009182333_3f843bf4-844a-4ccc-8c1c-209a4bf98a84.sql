-- Add blockchain transaction hash columns to products and supply_chain_entries
ALTER TABLE public.products 
ADD COLUMN blockchain_tx_hash TEXT,
ADD COLUMN blockchain_address TEXT;

ALTER TABLE public.supply_chain_entries
ADD COLUMN blockchain_tx_hash TEXT;

-- Add index for faster lookups
CREATE INDEX idx_products_blockchain_address ON public.products(blockchain_address);
CREATE INDEX idx_supply_chain_blockchain_tx ON public.supply_chain_entries(blockchain_tx_hash);