-- Add quantity_sold to products table for tracking sales
ALTER TABLE public.products 
ADD COLUMN IF NOT EXISTS quantity_sold INTEGER DEFAULT 0;

-- Add location field to profiles for farmer place information
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS location TEXT;

-- Create index for better query performance on category-based sales
CREATE INDEX IF NOT EXISTS idx_products_category ON public.products(category);
CREATE INDEX IF NOT EXISTS idx_products_quantity_sold ON public.products(quantity_sold DESC);