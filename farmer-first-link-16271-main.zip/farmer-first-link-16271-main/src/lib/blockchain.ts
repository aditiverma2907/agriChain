import { ethers } from 'ethers';

// CONFIGURATION: Update these after deploying your smart contract
export const AGRICHAIN_CONTRACT_ADDRESS = '0x0000000000000000000000000000000000000000'; // Replace with deployed contract address
export const BLOCKCHAIN_NETWORK = 'sepolia'; // or 'mumbai' for Polygon testnet

// Network configurations
export const NETWORKS = {
  sepolia: {
    chainId: '0xaa36a7', // 11155111 in hex
    chainName: 'Sepolia Test Network',
    rpcUrls: ['https://sepolia.infura.io/v3/'],
    blockExplorerUrls: ['https://sepolia.etherscan.io'],
    nativeCurrency: { name: 'Sepolia ETH', symbol: 'ETH', decimals: 18 }
  },
  mumbai: {
    chainId: '0x13881', // 80001 in hex
    chainName: 'Mumbai Testnet',
    rpcUrls: ['https://rpc-mumbai.maticvigil.com'],
    blockExplorerUrls: ['https://mumbai.polygonscan.com'],
    nativeCurrency: { name: 'MATIC', symbol: 'MATIC', decimals: 18 }
  }
};

// Contract ABI (minimal interface)
export const AGRICHAIN_ABI = [
  'function registerProduct(string productId, string name, string category, string origin, string farmerName, uint256 initialPrice) public',
  'function updateSupplyChain(string productId, uint8 stage, uint256 price, string location) public',
  'function getProduct(string productId) public view returns (string, string, string, string, uint256, address, uint256)',
  'function getSupplyChainLength(string productId) public view returns (uint256)',
  'function getSupplyChainEntry(string productId, uint256 index) public view returns (uint8, uint256, string, address, uint256)',
  'function productExists(string productId) public view returns (bool)',
  'event ProductRegistered(string indexed productId, string name, address indexed farmer, uint256 initialPrice, uint256 timestamp)',
  'event SupplyChainUpdated(string indexed productId, uint8 stage, uint256 price, address indexed updatedBy, uint256 timestamp)'
];

// Supply chain stages enum (matches Solidity contract)
export enum BlockchainStage {
  Farmer = 0,
  Wholesaler = 1,
  Retailer = 2,
  Consumer = 3
}

// Map app roles to blockchain stages
export const roleToStage: Record<string, BlockchainStage> = {
  farmer: BlockchainStage.Farmer,
  wholesaler: BlockchainStage.Wholesaler,
  retailer: BlockchainStage.Retailer,
  consumer: BlockchainStage.Consumer
};

export class BlockchainService {
  private provider: ethers.BrowserProvider | null = null;
  private signer: ethers.Signer | null = null;
  private contract: ethers.Contract | null = null;

  /**
   * Check if MetaMask or compatible wallet is installed
   */
  isWalletAvailable(): boolean {
    return typeof window !== 'undefined' && typeof window.ethereum !== 'undefined';
  }

  /**
   * Connect to user's wallet
   */
  async connectWallet(): Promise<string> {
    if (!this.isWalletAvailable()) {
      throw new Error('MetaMask or compatible wallet not installed');
    }

    try {
      this.provider = new ethers.BrowserProvider(window.ethereum);
      const accounts = await this.provider.send('eth_requestAccounts', []);
      this.signer = await this.provider.getSigner();
      
      // Check if on correct network
      const network = await this.provider.getNetwork();
      const targetNetwork = NETWORKS[BLOCKCHAIN_NETWORK as keyof typeof NETWORKS];
      
      if (network.chainId.toString() !== parseInt(targetNetwork.chainId, 16).toString()) {
        await this.switchNetwork();
      }
      
      this.contract = new ethers.Contract(
        AGRICHAIN_CONTRACT_ADDRESS,
        AGRICHAIN_ABI,
        this.signer
      );
      
      return accounts[0];
    } catch (error: any) {
      console.error('Error connecting wallet:', error);
      throw new Error(error.message || 'Failed to connect wallet');
    }
  }

  /**
   * Switch to the correct blockchain network
   */
  async switchNetwork(): Promise<void> {
    if (!this.provider) {
      throw new Error('Wallet not connected');
    }

    try {
      const targetNetwork = NETWORKS[BLOCKCHAIN_NETWORK as keyof typeof NETWORKS];
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: targetNetwork.chainId }],
      });
    } catch (switchError: any) {
      // Network not added, try to add it
      if (switchError.code === 4902) {
        try {
          const targetNetwork = NETWORKS[BLOCKCHAIN_NETWORK as keyof typeof NETWORKS];
          await window.ethereum.request({
            method: 'wallet_addEthereumChain',
            params: [targetNetwork],
          });
        } catch (addError) {
          throw new Error('Failed to add network');
        }
      } else {
        throw switchError;
      }
    }
  }

  /**
   * Get connected wallet address
   */
  async getAddress(): Promise<string> {
    if (!this.signer) {
      throw new Error('Wallet not connected');
    }
    return await this.signer.getAddress();
  }

  /**
   * Check if contract is deployed
   */
  isContractDeployed(): boolean {
    return AGRICHAIN_CONTRACT_ADDRESS !== '0x0000000000000000000000000000000000000000';
  }

  /**
   * Register a new product on the blockchain
   */
  async registerProduct(
    productId: string,
    name: string,
    category: string,
    origin: string,
    farmerName: string,
    initialPrice: number
  ): Promise<string> {
    if (!this.contract) {
      throw new Error('Contract not initialized. Please connect wallet first.');
    }

    if (!this.isContractDeployed()) {
      throw new Error('Smart contract not deployed. Please deploy the contract first.');
    }

    try {
      // Convert price to wei (assuming price is in ETH equivalent)
      const priceInWei = ethers.parseEther(initialPrice.toString());
      
      const tx = await this.contract.registerProduct(
        productId,
        name,
        category,
        origin,
        farmerName,
        priceInWei
      );
      
      await tx.wait();
      return tx.hash;
    } catch (error: any) {
      console.error('Error registering product:', error);
      throw new Error(error.message || 'Failed to register product on blockchain');
    }
  }

  /**
   * Update supply chain stage
   */
  async updateSupplyChain(
    productId: string,
    stage: BlockchainStage,
    price: number,
    location: string
  ): Promise<string> {
    if (!this.contract) {
      throw new Error('Contract not initialized. Please connect wallet first.');
    }

    if (!this.isContractDeployed()) {
      throw new Error('Smart contract not deployed. Please deploy the contract first.');
    }

    try {
      const priceInWei = ethers.parseEther(price.toString());
      
      const tx = await this.contract.updateSupplyChain(
        productId,
        stage,
        priceInWei,
        location
      );
      
      await tx.wait();
      return tx.hash;
    } catch (error: any) {
      console.error('Error updating supply chain:', error);
      throw new Error(error.message || 'Failed to update supply chain on blockchain');
    }
  }

  /**
   * Get product from blockchain
   */
  async getProduct(productId: string) {
    if (!this.contract) {
      throw new Error('Contract not initialized');
    }

    try {
      const result = await this.contract.getProduct(productId);
      return {
        name: result[0],
        category: result[1],
        origin: result[2],
        farmerName: result[3],
        initialPrice: ethers.formatEther(result[4]),
        farmer: result[5],
        timestamp: Number(result[6])
      };
    } catch (error: any) {
      console.error('Error getting product:', error);
      throw new Error('Failed to get product from blockchain');
    }
  }

  /**
   * Get supply chain history
   */
  async getSupplyChainHistory(productId: string) {
    if (!this.contract) {
      throw new Error('Contract not initialized');
    }

    try {
      const length = await this.contract.getSupplyChainLength(productId);
      const history = [];

      for (let i = 0; i < Number(length); i++) {
        const entry = await this.contract.getSupplyChainEntry(productId, i);
        history.push({
          stage: Number(entry[0]),
          price: ethers.formatEther(entry[1]),
          location: entry[2],
          updatedBy: entry[3],
          timestamp: Number(entry[4])
        });
      }

      return history;
    } catch (error: any) {
      console.error('Error getting supply chain history:', error);
      throw new Error('Failed to get supply chain history');
    }
  }

  /**
   * Check if product exists on blockchain
   */
  async productExists(productId: string): Promise<boolean> {
    if (!this.contract) {
      return false;
    }

    try {
      return await this.contract.productExists(productId);
    } catch (error) {
      return false;
    }
  }

  /**
   * Get transaction URL for block explorer
   */
  getTransactionUrl(txHash: string): string {
    const network = NETWORKS[BLOCKCHAIN_NETWORK as keyof typeof NETWORKS];
    return `${network.blockExplorerUrls[0]}/tx/${txHash}`;
  }
}

// Singleton instance
export const blockchainService = new BlockchainService();

// Type declarations for window.ethereum
declare global {
  interface Window {
    ethereum?: any;
  }
}
