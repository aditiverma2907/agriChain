export const translations = {
  en: {
    // Header & Navigation
    agrichain: "AgriChain",
    tagline: "Farm to Table Transparency",
    signIn: "Sign In",
    signOut: "Sign Out",
    language: "Language",
    
    // Home Page
    welcomeTitle: "Welcome to AgriChain",
    welcomeSubtitle: "Track your food journey from farm to table with complete transparency",
    
    // Roles
    farmer: "Farmer",
    retailer: "Retailer",
    wholesaler: "Wholesaler",
    consumer: "Consumer",
    
    farmerDesc: "Register and track your agricultural products",
    retailerDesc: "Manage product inventory and sales",
    wholesalerDesc: "Handle bulk product distribution",
    consumerDesc: "Track product origin and supply chain",
    
    goTo: "Go to",
    section: "Section",
    
    // Features
    features: "Features",
    qrTracking: "QR Code Tracking",
    qrTrackingDesc: "Scan QR codes to instantly access complete product history",
    transparency: "Full Transparency",
    transparencyDesc: "See every step of your product's journey",
    priceVisibility: "Price Visibility",
    priceVisibilityDesc: "Clear pricing at each stage of the supply chain",
    
    // Sales Analytics
    topCategories: "Top Selling Product Categories",
    salesByCategory: "Sales by Category",
    grains: "Grains",
    vegetables: "Vegetables",
    fruits: "Fruits",
    totalSales: "Total Sales",
    
    // Product Management
    productId: "Product ID",
    productName: "Product Name",
    category: "Category",
    origin: "Origin",
    location: "Location",
    farmerName: "Farmer Name",
    initialPrice: "Initial Price",
    currentPrice: "Current Price",
    price: "Price",
    registerProduct: "Register Product",
    updateSupplyChain: "Update Supply Chain",
    search: "Search",
    scanQR: "Scan QR Code",
    
    // Supply Chain
    supplyChainJourney: "Supply Chain Journey",
    stage: "Stage",
    timestamp: "Timestamp",
    
    // Blockchain
    blockchainVerified: "Blockchain Verified",
    blockchainPending: "Blockchain verification pending",
    connectWallet: "Connect Wallet",
    walletConnected: "Wallet Connected",
    
    // Checkout
    checkout: "Checkout",
    farmerDetails: "Farmer Details",
    phone: "Phone",
    email: "Email",
    place: "Place",
    priceBreakdown: "Price Breakdown",
    farmerPrice: "Farmer Price",
    finalPrice: "Final Price",
    totalAmount: "Total Amount",
    proceedToPayment: "Proceed to Payment",
    addToCart: "Add to Cart",
    buyNow: "Buy Now",
    
    // Messages
    loading: "Loading...",
    noDataFound: "No data found",
    error: "Error",
    success: "Success",
    productNotFound: "Product not found",
    enterProductId: "Enter Product ID to search",
    
    // Categories
    selectCategory: "Select Category",
    grain: "Grain",
    vegetable: "Vegetable",
    fruit: "Fruit",
  },
  
  hi: {
    // Header & Navigation
    agrichain: "एग्रीचेन",
    tagline: "खेत से मेज तक पारदर्शिता",
    signIn: "साइन इन करें",
    signOut: "साइन आउट करें",
    language: "भाषा",
    
    // Home Page
    welcomeTitle: "एग्रीचेन में आपका स्वागत है",
    welcomeSubtitle: "पूर्ण पारदर्शिता के साथ अपने भोजन की यात्रा को खेत से मेज तक ट्रैक करें",
    
    // Roles
    farmer: "किसान",
    retailer: "खुदरा विक्रेता",
    wholesaler: "थोक विक्रेता",
    consumer: "उपभोक्ता",
    
    farmerDesc: "अपने कृषि उत्पादों को पंजीकृत और ट्रैक करें",
    retailerDesc: "उत्पाद इन्वेंटरी और बिक्री प्रबंधित करें",
    wholesalerDesc: "थोक उत्पाद वितरण संभालें",
    consumerDesc: "उत्पाद की उत्पत्ति और आपूर्ति श्रृंखला को ट्रैक करें",
    
    goTo: "जाएं",
    section: "अनुभाग",
    
    // Features
    features: "विशेषताएं",
    qrTracking: "QR कोड ट्रैकिंग",
    qrTrackingDesc: "संपूर्ण उत्पाद इतिहास तक तुरंत पहुंचने के लिए QR कोड स्कैन करें",
    transparency: "पूर्ण पारदर्शिता",
    transparencyDesc: "अपने उत्पाद की यात्रा का हर कदम देखें",
    priceVisibility: "मूल्य दृश्यता",
    priceVisibilityDesc: "आपूर्ति श्रृंखला के प्रत्येक चरण पर स्पष्ट मूल्य निर्धारण",
    
    // Sales Analytics
    topCategories: "शीर्ष बिकने वाली उत्पाद श्रेणियां",
    salesByCategory: "श्रेणी के अनुसार बिक्री",
    grains: "अनाज",
    vegetables: "सब्जियां",
    fruits: "फल",
    totalSales: "कुल बिक्री",
    
    // Product Management
    productId: "उत्पाद आईडी",
    productName: "उत्पाद का नाम",
    category: "श्रेणी",
    origin: "मूल स्थान",
    location: "स्थान",
    farmerName: "किसान का नाम",
    initialPrice: "प्रारंभिक मूल्य",
    currentPrice: "वर्तमान मूल्य",
    price: "मूल्य",
    registerProduct: "उत्पाद पंजीकृत करें",
    updateSupplyChain: "आपूर्ति श्रृंखला अपडेट करें",
    search: "खोजें",
    scanQR: "QR कोड स्कैन करें",
    
    // Supply Chain
    supplyChainJourney: "आपूर्ति श्रृंखला यात्रा",
    stage: "चरण",
    timestamp: "समय",
    
    // Blockchain
    blockchainVerified: "ब्लॉकचेन सत्यापित",
    blockchainPending: "ब्लॉकचेन सत्यापन लंबित",
    connectWallet: "वॉलेट कनेक्ट करें",
    walletConnected: "वॉलेट कनेक्टेड",
    
    // Checkout
    checkout: "चेकआउट",
    farmerDetails: "किसान विवरण",
    phone: "फोन",
    email: "ईमेल",
    place: "स्थान",
    priceBreakdown: "मूल्य विवरण",
    farmerPrice: "किसान मूल्य",
    finalPrice: "अंतिम मूल्य",
    totalAmount: "कुल राशि",
    proceedToPayment: "भुगतान के लिए आगे बढ़ें",
    addToCart: "कार्ट में जोड़ें",
    buyNow: "अभी खरीदें",
    
    // Messages
    loading: "लोड हो रहा है...",
    noDataFound: "कोई डेटा नहीं मिला",
    error: "त्रुटि",
    success: "सफलता",
    productNotFound: "उत्पाद नहीं मिला",
    enterProductId: "खोजने के लिए उत्पाद आईडी दर्ज करें",
    
    // Categories
    selectCategory: "श्रेणी चुनें",
    grain: "अनाज",
    vegetable: "सब्जी",
    fruit: "फल",
  },
};

export type Language = keyof typeof translations;
export type TranslationKey = keyof typeof translations.en;
