import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { SupplyChainVisual } from "@/components/SupplyChainVisual";
import { QRScanner } from "@/components/QRScanner";
import { useLanguage } from "@/contexts/LanguageContext";
import { Product, SupplyChainEntry } from "@/types/product";
import { Search, CheckCircle2, Clock, ShoppingCart, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Consumer = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const { toast } = useToast();
  const [productId, setProductId] = useState("");
  const [product, setProduct] = useState<Product | null>(null);
  const [error, setError] = useState("");
  const [showScanner, setShowScanner] = useState(false);

  const handleSearch = async () => {
    if (!productId.trim()) {
      setError(t("enterProductId"));
      return;
    }

    setError("");
    try {
      const { data: productData, error: productError } = await supabase
        .from("products")
        .select("*")
        .eq("id", productId)
        .single();

      if (productError) throw productError;

      const { data: supplyChainData, error: supplyChainError } = await supabase
        .from("supply_chain_entries")
        .select("*")
        .eq("product_id", productId)
        .order("timestamp", { ascending: true });

      if (supplyChainError) throw supplyChainError;

      const transformedProduct: Product = {
        id: productData.id,
        name: productData.name,
        category: productData.category,
        origin: productData.origin,
        farmerName: productData.farmer_name,
        initialPrice: productData.initial_price,
        createdAt: productData.created_at,
        qrCode: productData.qr_code,
        supplyChain: supplyChainData.map((entry: any) => ({
          stage: entry.stage,
          price: entry.price,
          timestamp: entry.timestamp,
          location: entry.location,
        })),
      };

      setProduct(transformedProduct);
    } catch (err) {
      console.error("Error fetching product:", err);
      setError(t("productNotFound"));
      setProduct(null);
    }
  };

  const handleScan = async (data: string) => {
    setProductId(data);
    setShowScanner(false);
    
    try {
      const { data: productData, error: productError } = await supabase
        .from("products")
        .select("*")
        .eq("id", data)
        .single();

      if (productError) throw productError;

      const { data: supplyChainData, error: supplyChainError } = await supabase
        .from("supply_chain_entries")
        .select("*")
        .eq("product_id", data)
        .order("timestamp", { ascending: true });

      if (supplyChainError) throw supplyChainError;

      const transformedProduct: Product = {
        id: productData.id,
        name: productData.name,
        category: productData.category,
        origin: productData.origin,
        farmerName: productData.farmer_name,
        initialPrice: productData.initial_price,
        createdAt: productData.created_at,
        qrCode: productData.qr_code,
        supplyChain: supplyChainData.map((entry: any) => ({
          stage: entry.stage,
          price: entry.price,
          timestamp: entry.timestamp,
          location: entry.location,
        })),
      };

      setProduct(transformedProduct);
      setError("");
    } catch (err) {
      console.error("Error fetching product:", err);
      setError(t("productNotFound"));
      setProduct(null);
    }
  };

  const handleBuyNow = () => {
    if (!product) return;
    
    toast({
      title: t("success"),
      description: `${product.name} ${t("addToCart")}`,
    });
    
    navigate("/checkout", { state: { productIds: [product.id] } });
  };

  const getPriceBreakdown = () => {
    if (!product) return [];
    
    const breakdown = [
      { stage: t("farmer"), price: product.initialPrice },
    ];
    
    product.supplyChain.forEach((entry) => {
      breakdown.push({
        stage: entry.stage === "wholesaler" ? t("wholesaler") : t("retailer"),
        price: entry.price,
      });
    });
    
    return breakdown;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/20 p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <Button
            variant="ghost"
            onClick={() => navigate("/")}
            className="mb-4"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            {t("agrichain")}
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-3xl">{t("consumer")} {t("section")}</CardTitle>
            <CardDescription>{t("consumerDesc")}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <div className="flex-1">
                <Input
                  placeholder={t("productId")}
                  value={productId}
                  onChange={(e) => setProductId(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                />
              </div>
              <Button onClick={handleSearch}>
                <Search className="mr-2 h-4 w-4" />
                {t("search")}
              </Button>
              <Button onClick={() => setShowScanner(!showScanner)} variant="outline">
                {t("scanQR")}
              </Button>
            </div>

            {showScanner && (
              <div className="border rounded-lg p-4 bg-background">
                <QRScanner onScan={handleScan} onClose={() => setShowScanner(false)} />
              </div>
            )}

            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {product && (
          <>
            <Card>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-2xl">{product.name}</CardTitle>
                    <CardDescription className="mt-2">
                      {t("category")}: {product.category} | {t("origin")}: {product.origin}
                    </CardDescription>
                  </div>
                  <Badge variant="outline" className="text-lg px-4 py-2">
                    ₹{product.supplyChain[product.supplyChain.length - 1]?.price || product.initialPrice}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground">{t("farmerName")}</p>
                  <p className="font-medium">{product.farmerName}</p>
                </div>
                
                <div className="flex gap-2">
                  <Button onClick={handleBuyNow} className="flex-1" size="lg">
                    <ShoppingCart className="mr-2 h-4 w-4" />
                    {t("buyNow")}
                  </Button>
                </div>
              </CardContent>
            </Card>

            <SupplyChainVisual product={product} />

            <Card>
              <CardHeader>
                <CardTitle>{t("priceBreakdown")}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {getPriceBreakdown().map((item, index) => (
                    <div key={index} className="flex justify-between items-center py-2 border-b last:border-0">
                      <span className="capitalize">{item.stage}</span>
                      <span className="font-semibold">₹{item.price}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
};

export default Consumer;
