import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Leaf, Home, QrCode, LogOut } from "lucide-react";
import QRCodeLib from "qrcode";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useBlockchain } from "@/hooks/useBlockchain";
import { blockchainService } from "@/lib/blockchain";
import { WalletConnect } from "@/components/WalletConnect";
import { toast as sonnerToast } from "sonner";

const Farmer = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user, signOut, loading } = useAuth();
  const [profile, setProfile] = useState<any>(null);
  const [formData, setFormData] = useState({
    name: "",
    category: "",
    origin: "",
    initialPrice: "",
  });
  const [myProducts, setMyProducts] = useState<any[]>([]);
  const [showProducts, setShowProducts] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const { isConnected, isContractDeployed } = useBlockchain();

  useEffect(() => {
    if (!loading && !user) {
      navigate("/auth");
    }
  }, [user, loading, navigate]);

  useEffect(() => {
    if (user) {
      loadProfile();
    }
  }, [user]);

  const loadProfile = async () => {
    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", user?.id)
      .single();

    if (data) {
      setProfile(data);
      if (data.role !== "farmer") {
        toast({
          title: "Access Denied",
          description: "This page is only for farmers.",
          variant: "destructive",
        });
        navigate("/");
      }
    }
  };

  const generateProductId = () => {
    return `AGC${Date.now()}${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsRegistering(true);

    try {
      const productId = generateProductId();
      const qrCodeDataUrl = await QRCodeLib.toDataURL(productId);
      let blockchainTxHash = null;
      let blockchainAddress = null;

      // Register on blockchain if connected and contract is deployed
      if (isConnected && isContractDeployed) {
        try {
          sonnerToast.info("Registering product on blockchain...");
          blockchainTxHash = await blockchainService.registerProduct(
            productId,
            formData.name,
            formData.category,
            formData.origin,
            profile?.full_name || "Unknown",
            parseFloat(formData.initialPrice)
          );
          blockchainAddress = await blockchainService.getAddress();
          sonnerToast.success("Product registered on blockchain!", {
            description: `Transaction: ${blockchainTxHash.slice(0, 10)}...`,
          });
        } catch (blockchainError: any) {
          console.error("Blockchain error:", blockchainError);
          sonnerToast.error("Blockchain registration failed", {
            description: blockchainError.message,
          });
          // Continue with database only registration
        }
      }

      // Register in database
      const { error: productError } = await supabase.from("products").insert({
        id: productId,
        name: formData.name,
        category: formData.category,
        origin: formData.origin,
        farmer_id: user?.id,
        farmer_name: profile?.full_name || "Unknown",
        initial_price: parseFloat(formData.initialPrice),
        qr_code: qrCodeDataUrl,
        blockchain_tx_hash: blockchainTxHash,
        blockchain_address: blockchainAddress,
      });

      if (productError) {
        toast({
          title: "Error",
          description: productError.message,
          variant: "destructive",
        });
        return;
      }

      const { error: chainError } = await supabase.from("supply_chain_entries").insert({
        product_id: productId,
        stage: "farmer",
        user_id: user?.id,
        price: parseFloat(formData.initialPrice),
        location: formData.origin,
        blockchain_tx_hash: blockchainTxHash,
      });

      if (chainError) {
        toast({
          title: "Error",
          description: chainError.message,
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Product Registered Successfully!",
        description: blockchainTxHash 
          ? `Product ID: ${productId} (Blockchain verified)` 
          : `Product ID: ${productId}`,
      });

      setFormData({
        name: "",
        category: "",
        origin: "",
        initialPrice: "",
      });
    } finally {
      setIsRegistering(false);
    }
  };

  const loadMyProducts = async () => {
    const { data, error } = await supabase
      .from("products")
      .select("*")
      .eq("farmer_id", user?.id)
      .order("created_at", { ascending: false });

    if (data) {
      setMyProducts(data);
      setShowProducts(true);
    }
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Leaf className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold">Farmer Dashboard</h1>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => navigate("/")}>
              <Home className="h-4 w-4 mr-2" />
              Home
            </Button>
            <Button variant="outline" onClick={signOut}>
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>

        <WalletConnect />

        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Register New Product</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="name">Product Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="category">Category</Label>
              <Input
                id="category"
                placeholder="e.g., Vegetables, Fruits, Grains"
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="origin">Origin Location</Label>
              <Input
                id="origin"
                placeholder="e.g., Village, District, State"
                value={formData.origin}
                onChange={(e) => setFormData({ ...formData, origin: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="initialPrice">Initial Price (₹)</Label>
              <Input
                id="initialPrice"
                type="number"
                step="0.01"
                value={formData.initialPrice}
                onChange={(e) => setFormData({ ...formData, initialPrice: e.target.value })}
                required
              />
            </div>
            <Button type="submit" className="w-full" disabled={isRegistering}>
              {isRegistering ? "Registering..." : "Register Product & Generate QR Code"}
            </Button>
            {isConnected && isContractDeployed && (
              <p className="text-xs text-center text-muted-foreground">
                ✓ Product will be registered on blockchain
              </p>
            )}
          </form>
        </Card>

        <Button onClick={loadMyProducts} variant="outline" className="w-full">
          <QrCode className="h-4 w-4 mr-2" />
          View My Products & QR Codes
        </Button>

        {showProducts && myProducts.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {myProducts.map((product) => (
              <Card key={product.id} className="p-4">
                <h3 className="font-semibold text-lg mb-2">{product.name}</h3>
                <p className="text-sm text-muted-foreground mb-2">ID: {product.id}</p>
                <p className="text-sm mb-2">Category: {product.category}</p>
                <p className="text-sm mb-4">Price: ₹{product.initial_price}</p>
                {product.qr_code && (
                  <div className="bg-white p-4 rounded-lg inline-block">
                    <img src={product.qr_code} alt={`QR Code for ${product.name}`} className="w-48 h-48" />
                  </div>
                )}
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Farmer;
