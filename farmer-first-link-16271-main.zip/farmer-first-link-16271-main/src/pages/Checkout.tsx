import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useLanguage } from "@/contexts/LanguageContext";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, Phone, Mail, MapPin } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface CheckoutProduct {
  id: string;
  name: string;
  category: string;
  finalPrice: number;
  farmerDetails: {
    name: string;
    email: string;
    phone: string;
    location: string;
  };
  priceBreakdown: {
    farmerPrice: number;
    wholesalerPrice?: number;
    retailerPrice?: number;
  };
}

export default function Checkout() {
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useLanguage();
  const { toast } = useToast();
  const [products, setProducts] = useState<CheckoutProduct[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const productIds = location.state?.productIds as string[];
    if (!productIds || productIds.length === 0) {
      navigate("/consumer");
      return;
    }
    fetchCheckoutData(productIds);
  }, [location.state]);

  const fetchCheckoutData = async (productIds: string[]) => {
    try {
      const { data: productsData, error: productsError } = await supabase
        .from("products")
        .select("*, profiles!products_farmer_id_fkey(full_name, email, phone, location)")
        .in("id", productIds);

      if (productsError) throw productsError;

      const checkoutProducts: CheckoutProduct[] = await Promise.all(
        productsData.map(async (product) => {
          const { data: supplyChain } = await supabase
            .from("supply_chain_entries")
            .select("*")
            .eq("product_id", product.id)
            .order("timestamp", { ascending: true });

          let finalPrice = product.initial_price;
          const priceBreakdown: any = {
            farmerPrice: product.initial_price,
          };

          supplyChain?.forEach((entry) => {
            finalPrice = entry.price;
            if (entry.stage === "wholesaler") {
              priceBreakdown.wholesalerPrice = entry.price;
            } else if (entry.stage === "retailer") {
              priceBreakdown.retailerPrice = entry.price;
            }
          });

          return {
            id: product.id,
            name: product.name,
            category: product.category,
            finalPrice,
            farmerDetails: {
              name: product.profiles?.full_name || product.farmer_name,
              email: product.profiles?.email || "",
              phone: product.profiles?.phone || "",
              location: product.profiles?.location || product.origin,
            },
            priceBreakdown,
          };
        })
      );

      setProducts(checkoutProducts);
    } catch (error) {
      console.error("Error fetching checkout data:", error);
      toast({
        title: t("error"),
        description: "Failed to load checkout data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const totalAmount = products.reduce((sum, product) => sum + product.finalPrice, 0);

  const handleProceedToPayment = () => {
    toast({
      title: t("success"),
      description: "Payment processing will be integrated soon",
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background to-secondary/20 p-8">
        <div className="max-w-4xl mx-auto">
          <p className="text-center">{t("loading")}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/20 p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        <Button
          variant="ghost"
          onClick={() => navigate("/consumer")}
          className="mb-4"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          {t("consumer")}
        </Button>

        <h1 className="text-4xl font-bold">{t("checkout")}</h1>

        {products.map((product) => (
          <Card key={product.id} className="overflow-hidden">
            <CardHeader className="bg-primary/5">
              <CardTitle className="text-2xl">{product.name}</CardTitle>
              <p className="text-muted-foreground">
                {t("category")}: {product.category}
              </p>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  {t("farmerDetails")}
                </h3>
                <div className="grid gap-3 text-sm">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{t("farmerName")}:</span>
                    <span>{product.farmerDetails.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">{t("place")}:</span>
                    <span>{product.farmerDetails.location}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">{t("phone")}:</span>
                    <span>{product.farmerDetails.phone || "N/A"}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">{t("email")}:</span>
                    <span>{product.farmerDetails.email}</span>
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="text-lg font-semibold mb-4">{t("priceBreakdown")}</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>{t("farmerPrice")}:</span>
                    <span className="font-medium">₹{product.priceBreakdown.farmerPrice}</span>
                  </div>
                  {product.priceBreakdown.wholesalerPrice && (
                    <div className="flex justify-between">
                      <span>{t("wholesaler")} {t("price")}:</span>
                      <span className="font-medium">₹{product.priceBreakdown.wholesalerPrice}</span>
                    </div>
                  )}
                  {product.priceBreakdown.retailerPrice && (
                    <div className="flex justify-between">
                      <span>{t("retailer")} {t("price")}:</span>
                      <span className="font-medium">₹{product.priceBreakdown.retailerPrice}</span>
                    </div>
                  )}
                  <Separator />
                  <div className="flex justify-between text-lg font-bold">
                    <span>{t("finalPrice")}:</span>
                    <span className="text-primary">₹{product.finalPrice}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        <Card className="bg-primary/5">
          <CardContent className="p-6">
            <div className="flex justify-between items-center text-2xl font-bold">
              <span>{t("totalAmount")}:</span>
              <span className="text-primary">₹{totalAmount.toFixed(2)}</span>
            </div>
          </CardContent>
        </Card>

        <Button 
          onClick={handleProceedToPayment} 
          className="w-full" 
          size="lg"
        >
          {t("proceedToPayment")}
        </Button>
      </div>
    </div>
  );
}
