import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Store, Home, Search, LogOut } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { SupplyChainVisual } from "@/components/SupplyChainVisual";
import { useBlockchain } from "@/hooks/useBlockchain";
import { blockchainService, BlockchainStage, roleToStage } from "@/lib/blockchain";
import { WalletConnect } from "@/components/WalletConnect";
import { toast as sonnerToast } from "sonner";

const Retailer = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user, signOut, loading } = useAuth();
  const [profile, setProfile] = useState<any>(null);
  const [productId, setProductId] = useState("");
  const [product, setProduct] = useState<any | null>(null);
  const [priceIncrease, setPriceIncrease] = useState("");
  const [location, setLocation] = useState("");
  const [error, setError] = useState("");
  const [isUpdating, setIsUpdating] = useState(false);
  const { isConnected, isContractDeployed } = useBlockchain();

  useEffect(() => {
    if (!loading && !user) {
      navigate("/auth");
    }
  }, [user, loading, navigate]);

  useEffect(() => {
    if (user) {
      loadProfile();
    }
  }, [user]);

  const loadProfile = async () => {
    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", user?.id)
      .single();

    if (data) {
      setProfile(data);
      if (data.role !== "retailer") {
        toast({
          title: "Access Denied",
          description: "This page is only for retailers.",
          variant: "destructive",
        });
        navigate("/");
      }
    }
  };

  const handleSearch = async () => {
    setError("");
    const { data: productData, error: productError } = await supabase
      .from("products")
      .select("*")
      .eq("id", productId.trim())
      .single();

    if (productError || !productData) {
      setError("Product not found. Please check the Product ID.");
      setProduct(null);
      return;
    }

    // Get supply chain entries
    const { data: chainData } = await supabase
      .from("supply_chain_entries")
      .select("*")
      .eq("product_id", productId.trim())
      .order("timestamp", { ascending: true });

    // Check if retailer stage already exists
    const hasRetailer = chainData?.some((entry) => entry.stage === "retailer");
    if (hasRetailer) {
      setError("This product has already been processed by a retailer.");
      setProduct(null);
      return;
    }

    setProduct({ ...productData, supplyChain: chainData || [] });
  };

  const handleAddToChain = async () => {
    if (!product || !priceIncrease) {
      toast({
        title: "Error",
        description: "Please enter the price increase",
        variant: "destructive",
      });
      return;
    }

    setIsUpdating(true);

    try {
      const currentPrice = product.supplyChain[product.supplyChain.length - 1]?.price || product.initial_price;
      const newPrice = parseFloat(currentPrice) + parseFloat(priceIncrease);
      let blockchainTxHash = null;

      // Update on blockchain if connected and contract deployed
      if (isConnected && isContractDeployed && product.blockchain_address) {
        try {
          sonnerToast.info("Updating supply chain on blockchain...");
          blockchainTxHash = await blockchainService.updateSupplyChain(
            product.id,
            roleToStage["retailer"],
            newPrice,
            location || "Retailer location"
          );
          sonnerToast.success("Blockchain updated!", {
            description: `Transaction: ${blockchainTxHash.slice(0, 10)}...`,
          });
        } catch (blockchainError: any) {
          console.error("Blockchain error:", blockchainError);
          sonnerToast.error("Blockchain update failed", {
            description: blockchainError.message,
          });
          // Continue with database only update
        }
      }

      const { error } = await supabase.from("supply_chain_entries").insert({
        product_id: product.id,
        stage: "retailer",
        user_id: user?.id,
        price: newPrice,
        location: location || null,
        blockchain_tx_hash: blockchainTxHash,
      });

      if (error) {
        toast({
          title: "Error",
          description: error.message,
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Success!",
        description: blockchainTxHash 
          ? "Product added to retail supply chain (Blockchain verified)"
          : "Product added to retail supply chain",
      });

      setProduct(null);
      setProductId("");
      setPriceIncrease("");
      setLocation("");
    } finally {
      setIsUpdating(false);
    }
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Store className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold">Retailer Dashboard</h1>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => navigate("/")}>
              <Home className="h-4 w-4 mr-2" />
              Home
            </Button>
            <Button variant="outline" onClick={signOut}>
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>

        <WalletConnect />

        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Add Product to Retail Chain</h2>
          <div className="space-y-4">
            <div>
              <Label htmlFor="productId">Product ID</Label>
              <div className="flex gap-2">
                <Input
                  id="productId"
                  placeholder="e.g., AGC1736123456ABC"
                  value={productId}
                  onChange={(e) => setProductId(e.target.value)}
                />
                <Button onClick={handleSearch}>
                  <Search className="h-4 w-4 mr-2" />
                  Search
                </Button>
              </div>
            </div>

            {error && (
              <div className="p-4 bg-destructive/10 text-destructive rounded-lg">
                {error}
              </div>
            )}
          </div>
        </Card>

        {product && (
          <div className="space-y-6">
            <Card className="p-6">
              <h2 className="text-2xl font-bold mb-4">{product.name}</h2>
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <p className="text-sm text-muted-foreground">Product ID</p>
                  <p className="font-semibold">{product.id}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Category</p>
                  <p className="font-semibold">{product.category}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Farmer</p>
                  <p className="font-semibold">{product.farmer_name}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Current Price</p>
                  <p className="font-semibold text-primary text-xl">
                    ₹{product.supplyChain[product.supplyChain.length - 1]?.price || product.initial_price}
                  </p>
                </div>
              </div>

              <SupplyChainVisual product={product} />
            </Card>

            <Card className="p-6">
              <h3 className="text-xl font-semibold mb-4">Add to Retail Chain</h3>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="priceIncrease">Price Increase (₹)</Label>
                  <Input
                    id="priceIncrease"
                    type="number"
                    step="0.01"
                    placeholder="Enter price increase amount"
                    value={priceIncrease}
                    onChange={(e) => setPriceIncrease(e.target.value)}
                    required
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Current price: ₹{product.supplyChain[product.supplyChain.length - 1]?.price || product.initial_price}
                    {priceIncrease && ` → New price: ₹${(parseFloat(product.supplyChain[product.supplyChain.length - 1]?.price || product.initial_price) + parseFloat(priceIncrease)).toFixed(2)}`}
                  </p>
                </div>
                <div>
                  <Label htmlFor="location">Location (Optional)</Label>
                  <Input
                    id="location"
                    placeholder="e.g., Store name, City"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                  />
                </div>
                <Button onClick={handleAddToChain} className="w-full" size="lg" disabled={isUpdating}>
                  {isUpdating ? "Processing..." : "Add to Supply Chain"}
                </Button>
                {isConnected && isContractDeployed && product.blockchain_address && (
                  <p className="text-xs text-center text-muted-foreground">
                    ✓ Will be verified on blockchain
                  </p>
                )}
              </div>
            </Card>
          </div>
        )}

        {!product && !error && (
          <Card className="p-12 text-center">
            <Store className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
            <p className="text-muted-foreground">
              Enter a Product ID to add it to your retail supply chain
            </p>
          </Card>
        )}
      </div>
    </div>
  );
};

export default Retailer;
