import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { LanguageSelector } from "@/components/LanguageSelector";
import { SalesChart } from "@/components/SalesChart";
import { useLanguage } from "@/contexts/LanguageContext";
import { Sprout, Store, Warehouse, User, QrCode, Eye, DollarSign } from "lucide-react";

const Index = () => {
  const navigate = useNavigate();
  const { user, signOut } = useAuth();
  const { t } = useLanguage();

  const roles = [
    {
      icon: Sprout,
      title: t("farmer"),
      description: t("farmerDesc"),
      path: "/farmer",
      color: "text-green-600",
    },
    {
      icon: Store,
      title: t("retailer"),
      description: t("retailerDesc"),
      path: "/retailer",
      color: "text-blue-600",
    },
    {
      icon: Warehouse,
      title: t("wholesaler"),
      description: t("wholesalerDesc"),
      path: "/wholesaler",
      color: "text-purple-600",
    },
    {
      icon: User,
      title: t("consumer"),
      description: t("consumerDesc"),
      path: "/consumer",
      color: "text-orange-600",
    },
  ];

  const features = [
    {
      icon: QrCode,
      title: t("qrTracking"),
      description: t("qrTrackingDesc"),
    },
    {
      icon: Eye,
      title: t("transparency"),
      description: t("transparencyDesc"),
    },
    {
      icon: DollarSign,
      title: t("priceVisibility"),
      description: t("priceVisibilityDesc"),
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/20">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-primary">{t("agrichain")}</h1>
            <p className="text-sm text-muted-foreground">{t("tagline")}</p>
          </div>
          <div className="flex items-center gap-4">
            <LanguageSelector />
            {user ? (
              <Button onClick={signOut} variant="outline">
                {t("signOut")}
              </Button>
            ) : (
              <Button onClick={() => navigate("/auth")} variant="default">
                {t("signIn")}
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12 space-y-16">
        {/* Welcome Section */}
        <section className="text-center space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
            {t("welcomeTitle")}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {t("welcomeSubtitle")}
          </p>
        </section>

        {/* Sales Analytics Chart */}
        <section className="max-w-4xl mx-auto">
          <SalesChart />
        </section>

        {/* Role Cards */}
        <section>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {roles.map((role, index) => {
              const Icon = role.icon;
              return (
                <Card
                  key={index}
                  className="hover:shadow-lg transition-shadow cursor-pointer"
                  onClick={() => navigate(role.path)}
                >
                  <CardHeader>
                    <Icon className={`h-12 w-12 mb-2 ${role.color}`} />
                    <CardTitle>{role.title}</CardTitle>
                    <CardDescription>{role.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button className="w-full" variant="outline">
                      {t("goTo")} {role.title}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>

        {/* Features Section */}
        <section>
          <h3 className="text-3xl font-bold text-center mb-8">{t("features")}</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="text-center">
                  <CardHeader>
                    <Icon className="h-12 w-12 mx-auto mb-2 text-primary" />
                    <CardTitle>{feature.title}</CardTitle>
                    <CardDescription>{feature.description}</CardDescription>
                  </CardHeader>
                </Card>
              );
            })}
          </div>
        </section>
      </main>
    </div>
  );
};

export default Index;
