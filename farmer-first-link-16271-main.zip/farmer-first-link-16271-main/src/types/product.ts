export type SupplyChainStage = "farmer" | "retailer" | "wholesaler";

export interface SupplyChainEntry {
  stage: SupplyChainStage;
  price: number;
  timestamp: string;
  location?: string;
}

export interface Product {
  id: string;
  name: string;
  category: string;
  origin: string;
  farmerName: string;
  initialPrice: number;
  supplyChain: SupplyChainEntry[];
  createdAt: string;
  qrCode?: string;
}
