import { Product } from "@/types/product";
import { Card } from "@/components/ui/card";
import { ArrowRight, Leaf, Store, Building2 } from "lucide-react";

interface SupplyChainVisualProps {
  product: Product;
}

const stageIcons = {
  farmer: Leaf,
  retailer: Store,
  wholesaler: Building2,
};

const stageLabels = {
  farmer: "Farmer",
  retailer: "Retailer",
  wholesaler: "Wholesaler",
};

export const SupplyChainVisual = ({ product }: SupplyChainVisualProps) => {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Supply Chain Journey</h3>
      <div className="flex flex-col md:flex-row items-center gap-4">
        {product.supplyChain && product.supplyChain.length > 0 ? (
          product.supplyChain.map((entry, index) => {
            const Icon = stageIcons[entry.stage as keyof typeof stageIcons] || Store;
            return (
              <div key={index} className="flex items-center gap-4">
                <Card className="p-4 w-48">
                  <div className="flex flex-col items-center text-center gap-2">
                    <Icon className="h-8 w-8 text-primary" />
                    <div className="font-semibold">{stageLabels[entry.stage as keyof typeof stageLabels] || entry.stage}</div>
                    <div className="text-2xl font-bold text-primary">₹{typeof entry.price === 'number' ? entry.price.toFixed(2) : entry.price}</div>
                    <div className="text-xs text-muted-foreground">
                      {new Date(entry.timestamp).toLocaleDateString()}
                    </div>
                    {entry.location && (
                      <div className="text-xs text-muted-foreground">{entry.location}</div>
                    )}
                  </div>
                </Card>
                {index < product.supplyChain.length - 1 && (
                  <ArrowRight className="h-6 w-6 text-muted-foreground hidden md:block" />
                )}
              </div>
            );
          })
        ) : (
          <Card className="p-4 w-48">
            <div className="flex flex-col items-center text-center gap-2">
              <Leaf className="h-8 w-8 text-primary" />
              <div className="font-semibold">Farmer</div>
              <div className="text-2xl font-bold text-primary">₹{(product as any).initial_price || product.initialPrice}</div>
              <div className="text-xs text-muted-foreground">
                {new Date((product as any).created_at || product.createdAt).toLocaleDateString()}
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};
