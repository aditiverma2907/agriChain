import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";
import { supabase } from "@/integrations/supabase/client";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";

interface SalesData {
  category: string;
  sales: number;
}

export const SalesChart = () => {
  const { t } = useLanguage();
  const [data, setData] = useState<SalesData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSalesData();
  }, []);

  const fetchSalesData = async () => {
    try {
      const { data: products, error } = await supabase
        .from("products")
        .select("category, quantity_sold");

      if (error) throw error;

      // Aggregate sales by category
      const salesByCategory: Record<string, number> = {
        grain: 0,
        vegetable: 0,
        fruit: 0,
      };

      products?.forEach((product) => {
        const category = product.category.toLowerCase();
        if (category in salesByCategory) {
          salesByCategory[category] += product.quantity_sold || 0;
        }
      });

      const chartData: SalesData[] = [
        { category: t("grains"), sales: salesByCategory.grain },
        { category: t("vegetables"), sales: salesByCategory.vegetable },
        { category: t("fruits"), sales: salesByCategory.fruit },
      ];

      setData(chartData);
    } catch (error) {
      console.error("Error fetching sales data:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card className="w-full">
        <CardHeader>
          <Skeleton className="h-8 w-3/4" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-[300px] w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-2xl">{t("topCategories")}</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis 
              dataKey="category" 
              className="text-sm fill-foreground"
            />
            <YAxis className="text-sm fill-foreground" />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: "hsl(var(--background))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px"
              }}
            />
            <Legend />
            <Bar 
              dataKey="sales" 
              fill="hsl(var(--primary))" 
              name={t("totalSales")}
              radius={[8, 8, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};
