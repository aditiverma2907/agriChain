import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Wallet, LogOut, AlertCircle, ExternalLink } from "lucide-react";
import { useBlockchain } from "@/hooks/useBlockchain";
import { BLOCKCHAIN_NETWORK, NETWORKS } from "@/lib/blockchain";

export const WalletConnect = () => {
  const {
    walletAddress,
    isConnected,
    isConnecting,
    connectWallet,
    disconnectWallet,
    isWalletAvailable,
    isContractDeployed,
  } = useBlockchain();

  const formatAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  const networkConfig = NETWORKS[BLOCKCHAIN_NETWORK as keyof typeof NETWORKS];

  if (!isContractDeployed) {
    return (
      <Card className="p-4 bg-warning/10 border-warning">
        <div className="flex items-start gap-3">
          <AlertCircle className="h-5 w-5 text-warning mt-0.5" />
          <div className="flex-1">
            <h3 className="font-semibold text-warning mb-1">Contract Not Deployed</h3>
            <p className="text-sm text-muted-foreground mb-3">
              The smart contract hasn't been deployed yet. Deploy the contract first to enable blockchain features.
            </p>
            <a
              href="https://github.com/yourusername/agrichain/blob/main/contracts/README.md"
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm text-primary hover:underline inline-flex items-center gap-1"
            >
              View deployment instructions
              <ExternalLink className="h-3 w-3" />
            </a>
          </div>
        </div>
      </Card>
    );
  }

  if (!isWalletAvailable) {
    return (
      <Card className="p-4 bg-muted">
        <div className="flex items-start gap-3">
          <AlertCircle className="h-5 w-5 text-muted-foreground mt-0.5" />
          <div className="flex-1">
            <h3 className="font-semibold mb-1">Wallet Not Detected</h3>
            <p className="text-sm text-muted-foreground mb-3">
              Please install MetaMask or a compatible Web3 wallet to use blockchain features.
            </p>
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open('https://metamask.io/download/', '_blank')}
            >
              Install MetaMask
              <ExternalLink className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </div>
      </Card>
    );
  }

  if (isConnected && walletAddress) {
    return (
      <Card className="p-4 bg-primary/10 border-primary">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center">
              <Wallet className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Connected Wallet</p>
              <p className="font-mono font-semibold">{formatAddress(walletAddress)}</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Network: {networkConfig.chainName}
              </p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={disconnectWallet}>
            <LogOut className="h-4 w-4 mr-2" />
            Disconnect
          </Button>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Wallet className="h-8 w-8 text-muted-foreground" />
          <div>
            <h3 className="font-semibold">Connect Wallet</h3>
            <p className="text-sm text-muted-foreground">
              Connect to interact with blockchain
            </p>
          </div>
        </div>
        <Button onClick={connectWallet} disabled={isConnecting}>
          <Wallet className="h-4 w-4 mr-2" />
          {isConnecting ? 'Connecting...' : 'Connect'}
        </Button>
      </div>
    </Card>
  );
};
