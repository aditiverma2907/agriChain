import { useLanguage } from "@/contexts/LanguageContext";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Languages } from "lucide-react";

export const LanguageSelector = () => {
  const { language, setLanguage, t } = useLanguage();

  return (
    <div className="flex items-center gap-2">
      <Languages className="h-4 w-4" />
      <Select value={language} onValueChange={(value) => setLanguage(value as "en" | "hi")}>
        <SelectTrigger className="w-[140px] bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <SelectValue />
        </SelectTrigger>
        <SelectContent className="z-50 bg-background">
          <SelectItem value="en">English</SelectItem>
          <SelectItem value="hi">हिंदी (Hindi)</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
};
